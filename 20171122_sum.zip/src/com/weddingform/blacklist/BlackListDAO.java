package com.weddingform.blacklist;

//블랙리스트

public class BlackListDAO {

}

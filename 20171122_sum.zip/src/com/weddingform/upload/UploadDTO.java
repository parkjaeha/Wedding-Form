package com.weddingform.upload;

//�뾽濡쒕뱶 �궗吏�

public class UploadDTO {

	private int num;
	private String Fname;
	private String id;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	
	
	
}

package com.weddingform.invitation;

//청첩장 정보

public class InvitationDAO {

}

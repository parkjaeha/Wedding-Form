package com.weddingform.action;

//ActionForward

public class ActionForward {
	private String path;
	private boolean check;
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public boolean isCheck() {
		return check;
	}
	public void setCheck(boolean check) {
		this.check = check;
	}
	
	

}


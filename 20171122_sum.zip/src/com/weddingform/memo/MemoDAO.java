package com.weddingform.memo;

//청첩장 댓글

public class MemoDAO {

	
	//list
	
	//delete
	
	//insert
}

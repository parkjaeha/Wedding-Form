package com.weddingform.bookmark;

//즐겨찾기

public class BookmarkDAO {

}

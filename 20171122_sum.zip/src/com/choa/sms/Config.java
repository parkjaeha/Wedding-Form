package com.choa.sms;

public final class Config {
	public static final String appid = "weddingForm";
	public static final String apikey = "key";
	public static final String content = "인증번호: ";
	public static final String sender = "01086505104";
	public static final String receiver = "01086505104";
}

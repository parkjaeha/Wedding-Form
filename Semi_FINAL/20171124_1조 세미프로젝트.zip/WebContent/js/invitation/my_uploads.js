/**
 * 
 */
//Define some variables used to remember state.
var playlistId, nextPageToken, prevPageToken;
var count=0;
var title;
var videoId;
//After the API loads, call a function to get the uploads playlist ID.
//유트브 인증 후 id 불러오는것
function handleAPILoaded() {
	requestUserUploadsPlaylistId();
}


//Call the Data API to retrieve the playlist ID that uniquely identifies the
//list of videos uploaded to the currently authenticated user's channel.

//요청한 유저의 id를 토대로 list 불러오는것 
function requestUserUploadsPlaylistId() {
	// See https://developers.google.com/youtube/v3/docs/channels/list
	var request = gapi.client.youtube.channels.list({
		mine: true,
		part: 'contentDetails'
	});
	request.execute(function(response) {
		playlistId = response.result.items[0].contentDetails.relatedPlaylists.uploads;
		requestVideoPlaylist(playlistId);
	});
}

//Retrieve the list of videos in the specified playlist.
function requestVideoPlaylist(playlistId, pageToken) {
	$('#video-container').html();
	var requestOptions = {
			playlistId: playlistId,
			part: 'snippet',
			maxResults: 10
	};
	if (pageToken) {
		requestOptions.pageToken = pageToken;
	}
	var request = gapi.client.youtube.playlistItems.list(requestOptions);
	request.execute(function(response) {
		// Only show pagination buttons if there is a pagination token for the
		// next or previous page of results.
		nextPageToken = response.result.nextPageToken;
		var nextVis = nextPageToken ? 'visible' : 'hidden';
		$('#next-button').css('visibility', nextVis);
		prevPageToken = response.result.prevPageToken
		var prevVis = prevPageToken ? 'visible' : 'hidden';
		$('#prev-button').css('visibility', prevVis);

		var playlistItems = response.result.items;
		if (playlistItems) {
			$.each(playlistItems, function(index, item) {
				displayResult(item.snippet);
			});
		} else {
			$('#video-container').html('Sorry you have no uploaded videos');
		}
	});
}
//Create a listing for a video.
function displayResult(videoSnippet) {
	title = videoSnippet.title;
	videoId = videoSnippet.resourceId.videoId;
	$('#video-container').append("<p> <input type='radio' onclick='checkRadio("+count+");' class='racls' name='raname' value='"+videoId+"'> " + title+ "</p>");
	count=count+1;
		
	/*비디오 아이디를 넘겨서 재생시킨다. alert("videoId : "+videoId);*/
}
/*체크 라디오 함수*/
function checkRadio(n){
	
	var ra = document.getElementsByClassName('racls');
	
	for(var i = 0; i < ra.length; i++) {
		if(i == n*1) {
			alert(ra[i].value);
			window.document.getElementsByName('videourl')[0].value=ra[i].value;

		}
	}
}
//Retrieve the next page of videos in the playlist.
function nextPage() {
	requestVideoPlaylist(playlistId, nextPageToken);
}

//Retrieve the previous page of videos in the playlist.
function previousPage() {
	requestVideoPlaylist(playlistId, prevPageToken);
}

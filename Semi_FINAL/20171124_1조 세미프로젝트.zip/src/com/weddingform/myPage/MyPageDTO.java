package com.weddingform.myPage;

import com.weddingform.common.CommonDTO;

public class MyPageDTO extends CommonDTO{

	private String id;
	private String birth;
	private String gender;
	private String wedding_day;
	private String region;
	private String type;
	private String meal_cost;
	private String meal_menu;
	private String visitor;
	private String subway;
	private String hall_cost;
	private String hall_name;
	private String company_name;
	private String company_tel;
	private String company_number;
	
	
	
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getCompany_tel() {
		return company_tel;
	}
	public void setCompany_tel(String company_tel) {
		this.company_tel = company_tel;
	}
	public String getCompany_number() {
		return company_number;
	}
	public void setCompany_number(String company_number) {
		this.company_number = company_number;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMeal_cost() {
		return meal_cost;
	}
	public void setMeal_cost(String meal_cost) {
		this.meal_cost = meal_cost;
	}
	public String getMeal_menu() {
		return meal_menu;
	}
	public void setMeal_menu(String meal_menu) {
		this.meal_menu = meal_menu;
	}
	public String getVisitor() {
		return visitor;
	}
	public void setVisitor(String visitor) {
		this.visitor = visitor;
	}
	public String getSubway() {
		return subway;
	}
	public void setSubway(String subway) {
		this.subway = subway;
	}
	public String getHall_cost() {
		return hall_cost;
	}
	public void setHall_cost(String hall_cost) {
		this.hall_cost = hall_cost;
	}
	public String getHall_name() {
		return hall_name;
	}
	public void setHall_name(String hall_name) {
		this.hall_name = hall_name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getWedding_day() {
		return wedding_day;
	}
	public void setWedding_day(String wedding_day) {
		this.wedding_day = wedding_day;
	}
	
	

}

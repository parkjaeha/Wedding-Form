package com.weddingform.myPage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.weddingform.util.DBConnector;

public class MyPageDAO  {

	//delete
	public int delete(String id) throws Exception{
		Connection con=DBConnector.getConnect();
		String sql="delete common where id=?";
		PreparedStatement st=con.prepareStatement(sql);
		st.setString(1, id);
		int result=st.executeUpdate();
		DBConnector.disConnect(st, con);
		
		return result;
	}
	
	
	
	//update common
	public int updateC(MyPageDTO myPageDTO) throws Exception{
		Connection con=DBConnector.getConnect();
		String sql="update common set pw=?, name=?,addr=?, phone=?, email=? where id=?";
		PreparedStatement st=con.prepareStatement(sql);
		st.setString(1, myPageDTO.getPw());
		st.setString(2, myPageDTO.getName());
		st.setString(3, myPageDTO.getAddr());
		st.setString(4, myPageDTO.getPhone());
		st.setString(5, myPageDTO.getMail());
		st.setString(6, myPageDTO.getId());
		int result=st.executeUpdate();
		
		DBConnector.disConnect(st, con);
		
		return result;	
	}
	
	
	//update member
	public int updateM(MyPageDTO myPageDTO) throws Exception{
		Connection con=DBConnector.getConnect();
		String sql="update member set birth=?,wedding_day=? where id=?";
		PreparedStatement st=con.prepareStatement(sql);
		st.setString(1, myPageDTO.getBirth());
		st.setString(2, myPageDTO.getWedding_day());
		st.setString(3, myPageDTO.getId());
		int result=st.executeUpdate();
		
		DBConnector.disConnect(st, con);
		
		return result;
		
	}
	
	
	//update extra
	public int updateE(MyPageDTO myPageDTO) throws Exception{
		Connection con=DBConnector.getConnect();
		String sql="update extra set region=?, type=?, meal_cost=?, meal_menu=?, visitor=?, subway=?, hall_cost=? where id=?";
		PreparedStatement st=con.prepareStatement(sql);
		st.setString(1, myPageDTO.getRegion());
		st.setString(2, myPageDTO.getType());
		st.setString(3, myPageDTO.getMeal_cost());
		st.setString(4, myPageDTO.getMeal_menu());
		st.setString(5, myPageDTO.getVisitor());
		st.setString(6, myPageDTO.getSubway());
		st.setString(7, myPageDTO.getHall_cost());
		st.setString(8, myPageDTO.getId());
		int result=st.executeUpdate();
		
		DBConnector.disConnect(st, con);
		
		return result;
		
		
		
	}
	
	//company update
	public int updateCom(MyPageDTO myPageDTO) throws Exception{
		Connection con=DBConnector.getConnect();
		String sql="update company set company_name=?,company_tel=?,company_number=? where id=?";
		PreparedStatement st=con.prepareStatement(sql);
		st.setString(1, myPageDTO.getCompany_name());
		st.setString(2, myPageDTO.getCompany_tel());
		st.setString(3, myPageDTO.getCompany_number());
		st.setString(4, myPageDTO.getId());
		int result=st.executeUpdate();
		
		DBConnector.disConnect(st, con);
		
		return result;
		
	}
	
	
	
	//customer selectOne
	public MyPageDTO selectOne(MyPageDTO myPageDTO) throws Exception{
		Connection con=DBConnector.getConnect();
		String sql="select * from member M , common C, "
				+ "extra E where C.id=M.id and E.id = C.id and C.id=?";
		PreparedStatement st=con.prepareStatement(sql);
		st.setString(1, myPageDTO.getId());
	    ResultSet rs=st.executeQuery();
	    if(rs.next()) {
	    	myPageDTO.setId(rs.getString("id"));
	    	myPageDTO.setName(rs.getString("name"));
	    	myPageDTO.setPw(rs.getString("pw"));
	    	myPageDTO.setAddr(rs.getString("addr"));
	    	myPageDTO.setPhone(rs.getString("phone"));
	    	myPageDTO.setJob(rs.getString("job"));
	    	myPageDTO.setBirth(rs.getString("birth"));
	    	myPageDTO.setMail(rs.getString("email"));
	    	myPageDTO.setGender(rs.getString("gender"));
	    	myPageDTO.setWedding_day(rs.getString("wedding_day"));
	    	myPageDTO.setRegion(rs.getString("region"));
	    	myPageDTO.setType(rs.getString("type"));
	    	myPageDTO.setMeal_cost(rs.getString("meal_cost"));
	    	myPageDTO.setMeal_menu(rs.getString("meal_menu"));
	    	myPageDTO.setVisitor(rs.getString("visitor"));
	    	myPageDTO.setSubway(rs.getString("subway"));
	    	myPageDTO.setHall_cost(rs.getString("hall_cost"));
	    }else {
	    	myPageDTO=null;
	    }
	    
	    DBConnector.disConnect(rs, st, con);
	    
	    return myPageDTO;
	    
	    
		
		
	}
	
	
	//business selectOne
		public MyPageDTO selectOne2(MyPageDTO myPageDTO) throws Exception{
			Connection con=DBConnector.getConnect();
			String sql="select * from company M , common C, "
					+ "extra E where C.id=M.id and E.id = C.id and C.id=?";
			
			PreparedStatement st=con.prepareStatement(sql);
			st.setString(1, myPageDTO.getId());
		    ResultSet rs=st.executeQuery();
		    if(rs.next()) {
		    	myPageDTO.setId(rs.getString("id"));
		    	myPageDTO.setName(rs.getString("name"));
		    	myPageDTO.setPw(rs.getString("pw"));
		    	myPageDTO.setAddr(rs.getString("addr"));
		    	myPageDTO.setPhone(rs.getString("phone"));
		    	myPageDTO.setJob(rs.getString("job"));
		    	myPageDTO.setMail(rs.getString("email"));
		        myPageDTO.setCompany_name(rs.getString("company_name"));
		        myPageDTO.setCompany_number(rs.getString("company_number"));
		        myPageDTO.setCompany_tel(rs.getString("company_tel"));
		    	myPageDTO.setRegion(rs.getString("region"));
		    	myPageDTO.setType(rs.getString("type"));
		    	myPageDTO.setMeal_cost(rs.getString("meal_cost"));
		    	myPageDTO.setMeal_menu(rs.getString("meal_menu"));
		    	myPageDTO.setVisitor(rs.getString("visitor"));
		    	myPageDTO.setSubway(rs.getString("subway"));
		    	myPageDTO.setHall_cost(rs.getString("hall_cost"));
		    	myPageDTO.setHall_name(rs.getString("hall_name"));
		   
		    }else {
		    	myPageDTO=null;
		    	System.out.println("널이야");
		    }
		    
		    DBConnector.disConnect(rs, st, con);
		    
		    return myPageDTO;
		    
		    
			
			
		}
	
	
}

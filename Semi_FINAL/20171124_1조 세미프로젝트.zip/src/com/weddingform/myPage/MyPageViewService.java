package com.weddingform.myPage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.common.CommonDTO;

public class MyPageViewService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
   ActionForward actionForward=new ActionForward();
   HttpSession session = request.getSession();
   CommonDTO commonDTO = (CommonDTO)session.getAttribute("common");
  
   if(commonDTO == null) {
	   System.out.println("session이 안옴 ㅠㅠ");
   }
   
   
   MyPageDAO myPageDAO=new MyPageDAO();
   
   
   MyPageDTO myPageDTO=new MyPageDTO();
   myPageDTO.setId(commonDTO.getId());
 System.out.println(commonDTO.getId());

	   try {
			myPageDTO=myPageDAO.selectOne(myPageDTO);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	   
    request.setAttribute("member", myPageDTO);
    actionForward.setCheck(true);
    actionForward.setPath("../WEB-INF/view/myPage/memberMyPage.jsp");

   
		return actionForward;
	}

}

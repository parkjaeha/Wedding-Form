package com.weddingform.myPage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.plaf.ActionMapUIResource;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.common.CommonDTO;

public class MyPageUpdateService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionForward=new ActionForward();
		String method=request.getMethod();
		MyPageDAO myPageDAO=new MyPageDAO();
		
		HttpSession session=request.getSession();
		CommonDTO commonDTO=(CommonDTO)session.getAttribute("common");
		
		MyPageDTO myPageDTO=new MyPageDTO();
		   myPageDTO.setId(commonDTO.getId());
		
	
		   
		   try {
			myPageDTO=myPageDAO.selectOne(myPageDTO);
		   }catch (Exception e) {
			// TODO: handle exception
			   e.printStackTrace();
		}
	
	
		
		if(method.equals("POST")) {
	    	myPageDTO.setName(request.getParameter("name"));
	    	myPageDTO.setPw(request.getParameter("pw"));
	    	myPageDTO.setAddr(request.getParameter("addr_main"));
	    	myPageDTO.setPhone(request.getParameter("phone"));
	    	myPageDTO.setJob(request.getParameter("job"));
	    	myPageDTO.setBirth(request.getParameter("birth"));
	    	myPageDTO.setMail(request.getParameter("email"));
	    	myPageDTO.setGender(request.getParameter("gender"));
	    	myPageDTO.setWedding_day(request.getParameter("wedding_day"));
	    	myPageDTO.setRegion(request.getParameter("region"));
	    	myPageDTO.setType(request.getParameter("type"));
	    	myPageDTO.setMeal_cost(request.getParameter("meal_cost"));
	    	myPageDTO.setMeal_menu(request.getParameter("meal_menu"));
	    	myPageDTO.setVisitor(request.getParameter("visitor"));
	    	myPageDTO.setSubway(request.getParameter("subway"));
	    	myPageDTO.setHall_cost(request.getParameter("hall_cost"));
	  
	    	
	    	int result=0;
	    	try {
				result=myPageDAO.updateC(myPageDTO);
				result=myPageDAO.updateE(myPageDTO);
				result=myPageDAO.updateM(myPageDTO);
				
				if(result>0) {
					
					request.setAttribute("member", myPageDTO);
					actionForward.setCheck(false);
					actionForward.setPath("./myPageView.myPage");
					
				}else {
					request.setAttribute("message", "정보 수정 실패");
					actionForward.setCheck(true);
					actionForward.setPath("WEB-INF/view/common/result.jsp");
					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	    	
		}else {
			
			request.setAttribute("member", myPageDTO);
			actionForward.setCheck(true);
			actionForward.setPath("../WEB-INF/view/myPage/memberMyPageUpdate.jsp");

		}
		
		return actionForward;
	}

}

package com.weddingform.myPage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.common.CommonDTO;

public class ComMyPageViewService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionForward=new ActionForward();
		HttpSession session=request.getSession();
		CommonDTO commonDTO=(CommonDTO)session.getAttribute("common");
		if(commonDTO==null) {
			System.out.println("session 없어용");
		}
		
		MyPageDAO myPageDAO=new MyPageDAO();
		
		MyPageDTO myPageDTO=new MyPageDTO();
		myPageDTO.setId(commonDTO.getId());
		System.out.println("id"+commonDTO.getId());
		
		try {
			myPageDTO=myPageDAO.selectOne2(myPageDTO);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		request.setAttribute("member", myPageDTO);
		actionForward.setCheck(true);
		actionForward.setPath("../WEB-INF/view/myPage/comMyPage.jsp");
		
		return actionForward;
	}

}

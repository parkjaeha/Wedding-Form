package com.weddingform.myPage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.common.CommonDTO;

public class MyPageDeleteService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
   ActionForward actionForward=new ActionForward();
   HttpSession session=request.getSession();
	CommonDTO commonDTO=(CommonDTO)session.getAttribute("common");
	String id=commonDTO.getId();
	
		
      MyPageDAO myPageDAO=new MyPageDAO();
      
      int result=0;
      try {
		result=myPageDAO.delete(id);
	} catch (Exception e) {
		// TODO: handle exception
	}
      
      if(result>0) {
			request.setAttribute("message", "회원 탈퇴 성공");
		}else {
			request.setAttribute("message", "회원 탈퇴 실패");
		}
		
		request.getSession().invalidate();
		request.setAttribute("path", "../index.jsp");
		actionForward.setCheck(true);
		actionForward.setPath("../WEB-INF/view/common/result.jsp");
		return actionForward;
	}

}

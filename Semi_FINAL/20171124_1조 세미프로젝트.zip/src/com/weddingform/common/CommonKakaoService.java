package com.weddingform.common;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.company.CompanyDAO;
import com.weddingform.company.CompanyDTO;
import com.weddingform.extra.ExtraDAO;
import com.weddingform.extra.ExtraDTO;
import com.weddingform.member.MemberDAO;
import com.weddingform.member.MemberDTO;
import com.weddingform.util.DBConnector;

public class CommonKakaoService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionFoward = new ActionForward();
		String method = request.getMethod();
		System.out.println("Kako Join");
		HttpSession session = request.getSession();
		
		if(method.equals("GET")) {
			
			String type= request.getParameter("type");
			if(type.equals("move")) {
				actionFoward.setCheck(true);
				actionFoward.setPath("../main.jsp");
				
			}else if(type.equals("check")) {
			boolean check = true;
			String email = request.getParameter("email");
			email = email.replace("\"", "");
			
			CommonDAO commonDAO = new CommonDAO();
			CommonDTO commonDTO = null;
			try {
				check = commonDAO.idCheck(email);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("email : " +  email);
			if(check == false) {
				
				try {
					commonDTO=commonDAO.selectCheck(email,"id");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					commonDTO = null;
					e.printStackTrace();
				}
				
				session.setAttribute("common", commonDTO);
				request.setAttribute("result",true);
			}else {
				request.setAttribute("result",false);
			}
			
			actionFoward.setCheck(true);
			actionFoward.setPath("../WEB-INF/view/common/commonAuthResponse.jsp");

			}
			
		}else {
			
			Connection con =null;
			try {
				con = DBConnector.getConnect();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			CommonDTO commonDTO = new CommonDTO();
			CommonDAO commonDAO =new CommonDAO();
			ExtraDTO extraDTO = new ExtraDTO();
			ExtraDAO extraDAO = new ExtraDAO();
			MemberDTO memberDTO = null;
			MemberDAO memberDAO = null;
			CompanyDTO companyDTO = null;
			CompanyDAO companyDAO = null;
			
			
			String job = request.getParameter("job");
			String email = request.getParameter("kakao_email");
			String name = request.getParameter("kakao_name");
		
			String gender = "";
			String birth = "";
			String wedding_day = "";
			String company_name ="";
			String company_tel ="";
			String company_number ="";
			
			String region="";
			String type = "";
			String meal_cost="";
			String meal_menu ="";
			String visitor = "";
			String subway ="";
			String hall_cost = "";
			String hall_name = "";
			
			
			System.out.println("job: " +job);
			int result1 = 0,result2=0, result3=0;
			
			email = email.replace("\"", "");
			name = name.replace("\"", "");
			
			
			commonDTO.setId(email);
			commonDTO.setPw("kakao");
			commonDTO.setName(name);
			commonDTO.setJob(job);
			commonDTO.setAddr("kakao");
			commonDTO.setPhone("kakao");
			commonDTO.setMail(email);
			
			 region = request.getParameter("sido1") +" "+ request.getParameter("gugun1");	 
			 type = request.getParameter("type");
			 meal_cost = request.getParameter("meal_cost");
			 meal_menu = request.getParameter("meal_menu");
			 visitor = request.getParameter("visitor");
			 subway = request.getParameter("subway01")+" "+request.getParameter("subway02");
			 hall_cost = request.getParameter("hall_cost");
			 hall_name = request.getParameter("hall_name");
			
			System.out.println("id: "+ commonDTO.getId()+ " name : " +commonDTO.getName());
			try {
				result1 = commonDAO.insert(commonDTO, con);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("job:" +job);
			
			if(job.equals("Customer")) {
		

			memberDTO = new MemberDTO();
			memberDAO = new MemberDAO();
			gender  = request.getParameter("gender");
			birth = request.getParameter("birth");
			wedding_day = request.getParameter("wedding_day");
			 
			memberDTO.setId(email);
			memberDTO.setGender(gender);
			memberDTO.setBirth(birth);
			memberDTO.setWedding_day(wedding_day);
			 
			try {
				result2 = memberDAO.insert(memberDTO, con);
				System.out.println(memberDTO.getId());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			}else if(job.equals("Business")){
		
			companyDTO = new CompanyDTO();
			companyDAO = new CompanyDAO();
			
			company_name = request.getParameter("company_name");
			company_tel = request.getParameter("company_tel");
			company_number = request.getParameter("company_number");
			
		
			
			 System.out.println("id: "+ companyDTO.getId()+"region: " +region + " type: "+ type + " meal_cost: "+ meal_cost + "meal_menu: " + meal_menu+ "visitor: "+ visitor +" subway: "+ subway);
			 
			companyDTO.setId(email);
			companyDTO.setCompany_name(company_name);
			companyDTO.setCompany_tel(company_tel);
			companyDTO.setCompany_number(company_number);
			
				try {
					result2 = companyDAO.insert(companyDTO, con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			extraDTO.setId(email);
			extraDTO.setRegion(region);
			extraDTO.setType(type);
			extraDTO.setMeal_cost(meal_cost);
			extraDTO.setMeal_menu(meal_menu);
			extraDTO.setVisitor(visitor);
			extraDTO.setSubway(subway);
			extraDTO.setHall_cost(hall_cost);
			extraDTO.setHall_name(hall_name);
			
			try {

				 System.out.println("id: "+ extraDTO.getId()+" region: " +extraDTO.getRegion() + " type: "+ extraDTO.getType() + " meal_cost: "+ extraDTO.getHall_cost() + "meal_menu: " + extraDTO.getMeal_menu()+ "visitor: "+ visitor +" subway: "+ subway);
				
				result3 = extraDAO.insert(extraDTO, con);
				System.out.println("extra success");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("result: "+ result1 + "result2:" + result2+ "result3:" + result3);
			
			if(result1>0 && result2>0 && result3>0 ) {
				if(job.equals("Business")) {
				session.setAttribute("common", commonDTO);
				
				actionFoward.setCheck(true);
				actionFoward.setPath("../WEB-INF/view/function/Fileupload.jsp");
				}else {
					session.setAttribute("common", commonDTO);
					actionFoward.setCheck(true);
					actionFoward.setPath("../main.jsp");	
				}
			}else {
				
				request.setAttribute("message", "kako join fail");
				request.setAttribute("path", "./commonLogin.jsp");
				actionFoward.setCheck(true);
				actionFoward.setPath("../WEB-INF/view/common/result.jsp");
			}

		}
		return actionFoward;
	}

}

package com.weddingform.invitation;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

//筌ｏ옙筌ｂ뫗�삢 占쎌젟癰귨옙

public class InvitationDTO {
	
	
	
	
	private String id;
	private int num;
	private String m_name;
	private String w_name;
	private String m_tel;
	private String w_tel;
	private String time;
	private String wedding_date;
	private String wedding_addr;
	private String detail_information;
	private String VideoUrl;
	private String hall_name;
	private String wedding_addr_detail;
	private String d_day;
	
	
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getd_day(String str2) {
		Calendar cal2 = Calendar.getInstance ( ); 
		// �삤�뒛濡� �꽕�젙.
		
	
		String str[]=str2.split("-");
		
		Calendar cal3= Calendar.getInstance ( ); //�쁽�옱�궇吏�
		
		
		
		cal2.set(Integer.parseInt(str[0]), Integer.parseInt(str[1])-1, Integer.parseInt(str[2]));// �꽕�젙�궇吏�
		int count = 0; 
		while ( !cal3.after ( cal2 ) ) { 
		count++; 
		//�떎�쓬�궇濡� 諛붾��
		cal3.add ( Calendar.DATE, 1 );  
		} 
		
		return Integer.toString(count);
	}
	public String getWeek(String str2) {

		String m_week="";
		String str[]=str2.split("-");
	
		Calendar cal= Calendar.getInstance ( );
		
		cal.set(Integer.parseInt(str[0]), Integer.parseInt(str[1])-1, Integer.parseInt(str[2]));
		int day_of_week = cal.get ( Calendar.DAY_OF_WEEK );
		if ( day_of_week == 1 )
		m_week="일";
		else if ( day_of_week == 2 )
		m_week="월";
		else if ( day_of_week == 3 )
		m_week="화";
		else if ( day_of_week == 4 )
		m_week="수";
		else if ( day_of_week == 5 )
		m_week="목";
		else if ( day_of_week == 6 )
		m_week="금";
		else if ( day_of_week == 7 )
		m_week="토";
	
		return m_week;
	}
	public String getWedding_addr_detail() {
		return wedding_addr_detail;
	}
	public void setWedding_addr_detail(String wedding_addr_detail) {
		this.wedding_addr_detail = wedding_addr_detail;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getW_name() {
		return w_name;
	}
	public void setW_name(String w_name) {
		this.w_name = w_name;
	}
	public String getM_tel() {
		return m_tel;
	}
	public void setM_tel(String m_tel) {
		this.m_tel = m_tel;
	}
	public String getW_tel() {
		return w_tel;
	}
	public void setW_tel(String w_tel) {
		this.w_tel = w_tel;
	}
	public String getWedding_date() {
		return wedding_date;
	}
	public void setWedding_date(String wedding_date) {
		this.wedding_date = wedding_date;
	}
	public String getWedding_addr() {
		return wedding_addr;
	}
	public void setWedding_addr(String wedding_addr) {
		this.wedding_addr = wedding_addr;
	}
	public String getDetail_information() {
		return detail_information;
	}
	public void setDetail_information(String detail_information) {
		this.detail_information = detail_information;
	}
	
	public String getVideoUrl() {
		return VideoUrl;
	}
	public void setVideoUrl(String videoUrl) {
		VideoUrl = videoUrl;
	}
	public String getHall_name() {
		return hall_name;
	}
	public void setHall_name(String hall_name) {
		this.hall_name = hall_name;
	}
	
	
	
	
}

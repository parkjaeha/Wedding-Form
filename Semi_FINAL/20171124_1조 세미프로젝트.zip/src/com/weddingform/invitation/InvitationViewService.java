package com.weddingform.invitation;

import java.io.Console;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.eung.common.CommonDTO;
import com.weddingform.memo.MemoDAO;
import com.weddingform.memo.MemoDTO;
import com.weddingform.qna.QnaDAO;
import com.weddingform.qna.QnaDTO;
import com.weddingform.upload.UploadDAO;
import com.weddingform.upload.UploadDTO;
import com.weddingform.util.PageMaker;


public class InvitationViewService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionForward=new ActionForward();
		String method=request.getMethod();
		System.out.println("view service");
	
		
		if(method.equals("POST")) {
		
			System.out.println("IN POST");
			InvitationDAO  invitationDAO= new InvitationDAO();
			InvitationDTO  invitationDTO= new InvitationDTO();
			UploadDAO uploadDAO =new UploadDAO();
			UploadDTO uploadDTO =new UploadDTO();

			invitationDTO.setId("user03");
			
			
			invitationDTO.setM_name(request.getParameter("m_name"));
			invitationDTO.setW_name(request.getParameter("w_name"));
			invitationDTO.setM_tel(request.getParameter("m_tel"));
			invitationDTO.setW_tel(request.getParameter("w_tel"));
			invitationDTO.setWedding_date(request.getParameter("wedding_date"));																
			invitationDTO.setWedding_addr(request.getParameter("wedding_addr"));
			invitationDTO.setWedding_addr_detail(request.getParameter("invitation_addr_detail"));
			invitationDTO.setHall_name(request.getParameter("hall_name"));
			invitationDTO.setDetail_information(request.getParameter("detail_information"));
			invitationDTO.setVideoUrl(request.getParameter("videourl"));
			invitationDTO.setTime(request.getParameter("time"));

			uploadDTO.setId("iu");
			
			
			try {
				int result=invitationDAO.insert(invitationDTO);
				
				if(result > 0) {
					invitationDTO=invitationDAO.selectOne(invitationDTO);
					List<UploadDTO> ar=uploadDAO.selectALL(uploadDTO.getId());
						
					request.setAttribute("invitation", invitationDTO);
					request.setAttribute("imgList", ar);
					request.setAttribute("imgListSize", ar.size());
					request.setAttribute("week", invitationDTO.getWeek(invitationDTO.getWedding_date()));
					request.setAttribute("d_day", invitationDTO.getd_day(invitationDTO.getWedding_date()));
					
					
				} else {
					
				}
			}catch (Exception e) {
				e.printStackTrace();
			}

			//list selectList
			
			//////////////////////////////////////////////////////////////
			
			//////////////////////////////////////////////////////////////
			
			int curPage = 1;
			try {
				curPage = Integer.parseInt(request.getParameter("curPage"));
			} catch (Exception e) {	}
			
			MemoDAO memoDAO=new MemoDAO();
			try {
				PageMaker pageMaker = new PageMaker(1, 5*curPage, memoDAO.getTotal("user03"));
				List<MemoDTO> ar = memoDAO.selectList("user03", pageMaker.getMakeRow());
				
				request.setAttribute("list", ar);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
			
			////////////////////////////////////////////////////////////////////////////////////////////
			
			actionForward.setCheck(true);
			actionForward.setPath("../WEB-INF/view/invitation/invitationResult.jsp");	
		
		}else { // GET METHOD

			actionForward.setCheck(true);
			actionForward.setPath("../WEB-INF/view/invitation/invitationView.jsp");	
		}
		
		return actionForward;
	}

}

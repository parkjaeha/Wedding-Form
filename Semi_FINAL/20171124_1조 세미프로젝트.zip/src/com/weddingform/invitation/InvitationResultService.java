package com.weddingform.invitation;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;

public class InvitationResultService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionForward=new ActionForward();
		InvitationDTO invitationDTO =new InvitationDTO();
		InvitationDAO invitationDAO =new InvitationDAO();
		String id=request.getParameter("id");
		invitationDTO.setId(id);
		

		
		
		
		try {
			invitationDTO=invitationDAO.selectOne(invitationDTO);
			request.setAttribute("invitation", invitationDTO);
					
		} catch (Exception e) {
			
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
		
		
		
		actionForward.setCheck(true);
		actionForward.setPath("../WEB-INF/view/invitation/invitationResult.jsp");	
		
		return actionForward;
		
	}

}

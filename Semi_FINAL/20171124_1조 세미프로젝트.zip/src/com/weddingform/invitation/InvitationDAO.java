package com.weddingform.invitation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.weddingform.upload.UploadDTO;
import com.weddingform.util.DBConnector;

//筌ｏ옙筌ｂ뫗�삢 占쎌젟癰귨옙

public class InvitationDAO {


	public int insert(InvitationDTO invitationDTO) throws Exception {
		Connection con=DBConnector.getConnect();

		String sql="insert into "
				+ "invitation values(board_seq.nextval,?,?,?,?,?,?,?,?,?,?,?,?)";


		PreparedStatement st=con.prepareStatement(sql);
		
		st.setString(1, invitationDTO.getId());
		st.setString(2, invitationDTO.getM_name());
		st.setString(3, invitationDTO.getW_name());
		st.setString(4, invitationDTO.getM_tel());
		st.setString(5,invitationDTO.getW_tel());
		st.setString(6, invitationDTO.getWedding_date());
		st.setString(7, invitationDTO.getWedding_addr());
		st.setString(8, invitationDTO.getDetail_information());
		st.setString(9, invitationDTO.getVideoUrl());
		st.setString(10, invitationDTO.getHall_name());
		st.setString(11, invitationDTO.getWedding_addr_detail());
		st.setString(12, invitationDTO.getTime());
		

		int result=st.executeUpdate();

		DBConnector.disConnect(st, con);

		return result;



	}


	public InvitationDTO selectOne(InvitationDTO invitationDTO) throws Exception {
		Connection con=DBConnector.getConnect();
		String sql ="select * from invitation where id=?";

		PreparedStatement st = con.prepareStatement(sql);
		st.setString(1, invitationDTO.getId());
		try {
			ResultSet rs = st.executeQuery();

			if(rs.next()) {
				invitationDTO.setM_name(rs.getString("M_NAME"));
				invitationDTO.setW_name(rs.getString("W_NAME"));
				invitationDTO.setM_tel(rs.getString("M_TEL"));
				invitationDTO.setW_tel(rs.getString("W_TEL"));
				invitationDTO.setWedding_date(rs.getString("WEDDING_DATE"));
				invitationDTO.setWedding_addr(rs.getString("WEDDING_ADDR"));
				invitationDTO.setWedding_addr_detail(rs.getString("WEDDING_ADDR_DETAIL"));
				invitationDTO.setHall_name(rs.getString("HALL_NAME"));
				invitationDTO.setDetail_information(rs.getString("DETAIL_INFORMATION"));
				invitationDTO.setVideoUrl(rs.getString("VIDEOURL"));
				invitationDTO.setTime(rs.getString("TIME"));
				
				DBConnector.disConnect(rs, st, con);

			}
		}catch (Exception e) {
			// TODO: handle exception
		}


		return invitationDTO;

	}

	
	public List<UploadDTO> selectList(String id) throws Exception {
		Connection con = DBConnector.getConnect();
		
		List<UploadDTO> ar = new ArrayList<>();
		
		String sql ="select * from uploads where id = ? order by num;"; 
				
				PreparedStatement st = con.prepareStatement(sql);
		st.setString(1,id);
		ResultSet rs = st.executeQuery();
		
		while(rs.next()) {
			UploadDTO uploadDTO = new UploadDTO();
			uploadDTO.setNum(rs.getInt("num"));
			uploadDTO.setFname(rs.getString("FNAME"));
			uploadDTO.setId(id);
			
			ar.add(uploadDTO);
		}
		
		DBConnector.disConnect(rs, st, con);
		
		return ar;
	}
	
}

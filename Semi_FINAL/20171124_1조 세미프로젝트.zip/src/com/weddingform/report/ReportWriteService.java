package com.weddingform.report;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.common.CommonDTO;

public class ReportWriteService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionForward=new ActionForward();
		String method=request.getMethod();
		ReportDAO reportDAO=new ReportDAO();
		ReportDTO reportDTO=new ReportDTO();
		HttpSession session=request.getSession();
		CommonDTO commonDTO=(CommonDTO)session.getAttribute("common");
		request.setAttribute("session", commonDTO.getId());
	
		
		if(method.equals("POST")) {
	    reportDTO.setId(request.getParameter("id"));
		reportDTO.setTitle(request.getParameter("title"));
		reportDTO.setPw(request.getParameter("password"));
		reportDTO.setContents(request.getParameter("contents"));
		reportDTO.setCompany_name(request.getParameter("company_name"));
		int result=0;
		try {
			 result=reportDAO.insert(reportDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(result>0) {
		request.setAttribute("message", "신고가 완료되었습니다.");
		request.setAttribute("path", "../index.jsp");
		actionForward.setCheck(true);
		actionForward.setPath("../WEB-INF/view/common/result.jsp");
		}else {
			request.setAttribute("message", "오류!! 다시 작성해주세요.");

			actionForward.setCheck(true);
			actionForward.setPath("../WEB-INF/view/common/result.jsp");
		}
		
		}else {
			
			actionForward.setCheck(true);
			actionForward.setPath("../WEB-INF/view/board/reportWrite.jsp");
		}
		
		
		return actionForward;
	}

}
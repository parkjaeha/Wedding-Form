package com.weddingform.function;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.common.CommonDAO;
import com.weddingform.common.CommonDTO;

public class PaymentService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionFoward = new ActionForward();
		String method = request.getMethod();
		System.out.println("payment service");
		HttpSession session = request.getSession();
	
		CommonDTO commonDTO= new CommonDTO();
		try {
		commonDTO = (CommonDTO) session.getAttribute("common");
		System.out.println("payment id : " + commonDTO.getId() + " payment tel : " + commonDTO.getPhone() + " payment name : " + commonDTO.getName()+ " payment email : " + commonDTO.getMail());
		}catch (Exception e) {
			// TODO: handle exception
			commonDTO.setId("error");
			commonDTO.setPhone("error");
			commonDTO.setName("error");
			commonDTO.setMail("error");
		}
		if(method.equals("GET")) {
			
				
				actionFoward.setCheck(true);
				actionFoward.setPath("../WEB-INF/view/common/commonAuthResponse.jsp");
			
		}else {
				
			request.setAttribute("id", commonDTO.getId());
			request.setAttribute("tel", commonDTO.getPhone());
			request.setAttribute("name", commonDTO.getName());
			request.setAttribute("email", commonDTO.getMail());

				session.setAttribute("common", commonDTO);
				actionFoward.setCheck(true);
				actionFoward.setPath("../WEB-INF/view/function/payment.jsp");
			
		}
		return actionFoward;
	}

}

package com.weddingform.function;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.common.CommonDTO;
import com.weddingform.upload.UploadDAO;


public class UploadDeleteService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionForward  = new ActionForward();

		System.out.println("Upload Delete");
		
		String method = request.getMethod();
		/*HttpSession session = request.getSession();
		System.out.println("session: " + session);
		System.out.println("session: " + session.getAttribute("common"));
		*/
		if(method.equals("GET")) {
			
			System.out.println("GET");
			
			
			actionForward.setCheck(true);
			actionForward.setPath("../index.jsp");

		}else {
			
			System.out.println("POST");
			//CommonDTO commonDTO = (CommonDTO) session.getAttribute("common");
			UploadDAO uploadDAO = new UploadDAO();
			
			int num  = 0 ; 
			int result = 0;
			try {
			num = Integer.parseInt(request.getParameter("num"));
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			String fname = request.getParameter("fname");
			String id = "iu";
			try {
			//id = commonDTO.getId();
				System.out.println("id: " +id+" num: "+ num + " fname: "+ fname);
			}catch (Exception e) {
				// TODO: handle exception
				id="iu";
			}
			
			try {
				result =  uploadDAO.delete(num,fname,id);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(result>0) {
				System.out.println("success");
			}
			request.setAttribute("result", true);
			actionForward.setCheck(true);
			actionForward.setPath("../WEB-INF/view/common/commonAuthResponse.jsp");
			
		}

		return actionForward;
	}

}

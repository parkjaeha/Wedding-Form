package com.weddingform.notice;

import com.weddingform.Board.BoardDTO;

//공지 게시판

public class NoticeDTO extends BoardDTO{

}

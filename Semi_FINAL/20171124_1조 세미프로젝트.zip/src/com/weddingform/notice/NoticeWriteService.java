package com.weddingform.notice;

import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weddingform.notice.NoticeDAO;
import com.weddingform.notice.NoticeDTO;
import com.weddingform.action.Action;
import com.weddingform.action.ActionForward;
import com.weddingform.common.CommonDTO;

//공지 게시판 쓰기 서비스

public class NoticeWriteService implements Action {

	@Override
	public ActionForward doProcess(HttpServletRequest request, HttpServletResponse response) {
		ActionForward actionForward=new ActionForward();
		String method=request.getMethod();
		
		
		
		HttpSession session=request.getSession();
		CommonDTO commonDTO=(CommonDTO)session.getAttribute("common");
		request.setAttribute("session", commonDTO.getId());
		System.out.println(commonDTO.getId());
		
		if(method.equals("POST")) {
			
			   
			NoticeDAO noticeDAO=new NoticeDAO();
			NoticeDTO noticeDTO=new NoticeDTO();
			noticeDTO.setTitle(request.getParameter("title"));
			noticeDTO.setWriter(request.getParameter("writer"));
			noticeDTO.setContents(request.getParameter("contents"));
			
			try {
				int result=noticeDAO.insert(noticeDTO);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			actionForward.setCheck(false);
			actionForward.setPath("./noticeList.notice");
			
		}else {
			request.setAttribute("board", "notice");
			actionForward.setCheck(true);
			actionForward.setPath("../WEB-INF/view/board/boardWrite.jsp");
		}


			
			return actionForward;
		}


}
